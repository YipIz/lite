/*
 * Copyright (c) 2018, Adam <Adam@sigterm.info>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package net.runelite.http.service.chat;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.runelite.http.api.chat.Duels;
import net.runelite.http.api.chat.LayoutRoom;
import net.runelite.http.api.chat.Task;
import net.runelite.http.service.util.exception.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/chat")
public class ChatController
{
	private static final Pattern STRING_VALIDATION = Pattern.compile("[^a-zA-Z0-9' -]");
	private static final int STRING_MAX_LENGTH = 50;
	private static final int MAX_LAYOUT_ROOMS = 16;
	private static final int MAX_PETS = 256;

	private final Cache<KillCountKey, Integer> killCountCache = CacheBuilder.newBuilder()
		.expireAfterWrite(2, TimeUnit.MINUTES)
		.maximumSize(128L)
		.build();

	@Autowired
	private ChatService chatService;

	@PostMapping("/kc")
	public void submitKc(@RequestParam String name, @RequestParam String boss, @RequestParam int kc)
	{
		if (kc <= 0)
		{
			return;
		}

		chatService.setKc(name, boss, kc);
		killCountCache.put(new KillCountKey(name, boss), kc);
	}

	@GetMapping("/kc")
	public int getKc(@RequestParam String name, @RequestParam String boss)
	{
		Integer kc = killCountCache.getIfPresent(new KillCountKey(name, boss));
		if (kc == null)
		{
			kc = chatService.getKc(name, boss);
			if (kc != null)
			{
				killCountCache.put(new KillCountKey(name, boss), kc);
			}
		}

		if (kc == null)
		{
			throw new NotFoundException();
		}
		return kc;
	}

	@PostMapping("/qp")
	public void submitQp(@RequestParam String name, @RequestParam int qp)
	{
		if (qp < 0)
		{
			return;
		}

		chatService.setQp(name, qp);
	}

	@GetMapping("/qp")
	public int getQp(@RequestParam String name)
	{
		Integer kc = chatService.getQp(name);
		if (kc == null)
		{
			throw new NotFoundException();
		}
		return kc;
	}

	@PostMapping("/gc")
	public void submitGc(@RequestParam String name, @RequestParam int gc)
	{
		if (gc < 0)
		{
			return;
		}

		chatService.setGc(name, gc);
	}

	@GetMapping("/gc")
	public int getKc(@RequestParam String name)
	{
		Integer gc = chatService.getGc(name);
		if (gc == null)
		{
			throw new NotFoundException();
		}
		return gc;
	}

	@PostMapping("/task")
	public void submitTask(@RequestParam String name, @RequestParam("task") String taskName, @RequestParam int amount,
		@RequestParam int initialAmount, @RequestParam String location)
	{
		Matcher mTask = STRING_VALIDATION.matcher(taskName);
		Matcher mLocation = STRING_VALIDATION.matcher(location);
		if (mTask.find() || taskName.length() > STRING_MAX_LENGTH ||
			mLocation.find() || location.length() > STRING_MAX_LENGTH)
		{
			return;
		}

		Task task = new Task();
		task.setTask(taskName);
		task.setAmount(amount);
		task.setInitialAmount(initialAmount);
		task.setLocation(location);

		chatService.setTask(name, task);
	}

	@GetMapping("/task")
	public ResponseEntity<Task> getTask(@RequestParam String name)
	{
		Task task = chatService.getTask(name);
		if (task == null)
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
				.build();
		}

		return ResponseEntity.ok()
			.cacheControl(CacheControl.maxAge(2, TimeUnit.MINUTES).cachePublic())
			.body(task);
	}

	@PostMapping("/pb")
	public void submitPb(@RequestParam String name, @RequestParam String boss, @RequestParam double pb)
	{
		if (pb < 0)
		{
			return;
		}

		chatService.setPb(name, boss, pb);
	}

	@GetMapping("/pb")
	public double getPb(@RequestParam String name, @RequestParam String boss)
	{
		Double pb = chatService.getPb(name, boss);
		if (pb == null)
		{
			throw new NotFoundException();
		}
		return pb;
	}

	@PostMapping("/duels")
	public void submitDuels(@RequestParam String name, @RequestParam int wins,
		@RequestParam int losses,
		@RequestParam int winningStreak, @RequestParam int losingStreak)
	{
		if (wins < 0 || losses < 0 || winningStreak < 0 || losingStreak < 0)
		{
			return;
		}

		Duels duels = new Duels();
		duels.setWins(wins);
		duels.setLosses(losses);
		duels.setWinningStreak(winningStreak);
		duels.setLosingStreak(losingStreak);

		chatService.setDuels(name, duels);
	}

	@GetMapping("/duels")
	public Duels getDuels(@RequestParam String name)
	{
		Duels duels = chatService.getDuels(name);
		if (duels == null)
		{
			throw new NotFoundException();
		}
		return duels;
	}

	@PostMapping("/layout")
	public void submitLayout(@RequestParam String name, @RequestBody LayoutRoom[] rooms)
	{
		if (rooms.length > MAX_LAYOUT_ROOMS)
		{
			return;
		}

		chatService.setLayout(name, rooms);
	}

	@GetMapping("/layout")
	public LayoutRoom[] getLayout(@RequestParam String name)
	{
		LayoutRoom[] layout = chatService.getLayout(name);

		if (layout == null)
		{
			throw new NotFoundException();
		}

		return layout;
	}

	@PostMapping("/pets")
	public void submitPetList(@RequestParam String name, @RequestBody int[] petList)
	{
		if (petList.length == 0 || petList.length > MAX_PETS)
		{
			return;
		}

		chatService.setPetList(name, petList);
	}

	@GetMapping("/pets")
	public int[] getPetList(@RequestParam String name)
	{
		int[] petList = chatService.getPetList(name);
		if (petList == null)
		{
			throw new NotFoundException();
		}

		return petList;
	}
}
